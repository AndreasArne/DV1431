package se.bth.students.quizzard.logic;

/**
 * Created by mihai on 2014-11-25.
 */
public class Answer {
}
